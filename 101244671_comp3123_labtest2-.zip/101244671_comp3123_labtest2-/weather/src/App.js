import './App.css';
import Toronto from './Toronto';


function App() {
 
  return (
      
    <Toronto />
    
  );
}

export default App;
